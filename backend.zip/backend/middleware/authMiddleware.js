// Example: verify JWT & check if user is admin
const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.verifyAdmin = (req, res, next) => {
  console.log('Admin session:', req.session);
  if (!req.session.isAdmin) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  next();
};
