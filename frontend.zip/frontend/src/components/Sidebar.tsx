// src/components/Sidebar.tsx

import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import '../styles/dashboard.css';

// ✅ Sidebar needs isOpen prop for mobile toggle
interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/user/profile', {
          withCredentials: true,
        });
        if (res.status === 200) {
          setIsLoggedIn(true);
        }
      } catch (err) {
        setIsLoggedIn(false);
      }
    };
    checkSession();
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/api/auth/logout', {}, {
        withCredentials: true,
      });
      setIsLoggedIn(false);
      navigate('/login');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
      {/* Top */}
      <div>
        <div className="logo">Crypto</div>

        <nav className="menu">
          <Link
            to="/"
            className={`menu-btn ${location.pathname === '/' ? 'active' : ''}`}
          >
            Dashboard
          </Link>

          {isLoggedIn ? (
            <>
              <Link
                to="/wallet"
                className={`menu-btn ${location.pathname === '/wallet' ? 'active' : ''}`}
              >
                Wallet
              </Link>
              <Link
                to="/profile"
                className={`menu-btn ${location.pathname === '/profile' ? 'active' : ''}`}
              >
                Profile
              </Link>
            </>
          ) : (
            <Link
              to="/login"
              className="menu-btn"
              style={{
                backgroundColor: '#facc15',
                color: '#000',
                fontWeight: 600,
              }}
            >
              Login / SignUp
            </Link>
          )}
        </nav>
      </div>

      {/* Bottom */}
      <div className="mt-auto">
        {isLoggedIn && (
          <button className="menu-btn w-full mb-4" onClick={handleLogout}>
            Logout
          </button>
        )}
        <footer className="footer">&copy; 2025 Whitestone Capital</footer>
      </div>
    </aside>
  );
}
